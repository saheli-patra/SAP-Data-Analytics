"""
SAP MM — Procure-to-Pay (P2P) Full Cycle Simulation
====================================================
KIIT University | SAP Capstone Project 2026
Student : Saheli Patra | Roll: 23051293
Module  : SAP MM
"""

from datetime import date, timedelta
import random

# ─────────────────────────────────────────────
#  Organisation Master Data  (mirroring SPRO)
# ─────────────────────────────────────────────
ORG = {
    "client"         : "800",
    "company_code"   : "KE01",
    "plant"          : "KP01",
    "storage_loc"    : "KS01",
    "purch_org"      : "KPO1",
    "purch_group"    : "KPG",
    "chart_of_accts" : "KIIT",
    "fiscal_yr"      : "K4",
}

VENDOR_MASTER = {
    "V-1001": {
        "name"         : "ABC Supplies Pvt. Ltd.",
        "payment_terms": "OD06",   # Net 30 days
        "bank"         : "HDFC001",
        "currency"     : "INR",
    }
}

MATERIAL_MASTER = {
    "MAT-RAW-001": {
        "description"  : "Steel Rods — 12 mm",
        "material_group": "MG-RAW",
        "unit"         : "KG",
        "stock"        : 500,          # current unrestricted stock
        "valuation"    : 85.00,        # price per KG (INR)
    }
}

TOLERANCE_PCT = 5.0   # Invoice variance tolerance (%)

# ─────────────────────────────────────────────
#  Shared document store (simulates SAP DB)
# ─────────────────────────────────────────────
_store = {
    "pr"      : {},
    "rfq"     : {},
    "quotes"  : {},   # rfq_no → list of vendor quotes
    "po"      : {},
    "gr"      : {},
    "invoice" : {},
    "payment" : {},
    "fi_docs" : [],   # accounting documents
}
_counters = {"pr": 1000, "rfq": 2000, "po": 3000,
             "gr": 4000, "inv": 5000, "pay": 6000, "fi": 9000}

def _next(doc_type: str) -> str:
    _counters[doc_type] += 1
    return str(_counters[doc_type])


# ══════════════════════════════════════════════
#  PHASE 1 — Purchase Requisition  (ME51N)
# ══════════════════════════════════════════════
def create_purchase_requisition(material: str, qty: float,
                                account_category: str = "K") -> str:
    """T-Code ME51N — Create Purchase Requisition."""
    mat = MATERIAL_MASTER.get(material)
    if not mat:
        raise ValueError(f"Material {material} not found in master data.")

    pr_no = _next("pr")
    _store["pr"][pr_no] = {
        "status"          : "OPEN",
        "material"        : material,
        "description"     : mat["description"],
        "qty"             : qty,
        "unit"            : mat["unit"],
        "plant"           : ORG["plant"],
        "storage_loc"     : ORG["storage_loc"],
        "item_category"   : "Standard",
        "acct_category"   : account_category,
        "purch_group"     : ORG["purch_group"],
        "created_on"      : date.today(),
        "release_status"  : "PENDING",
    }
    print(f"\n{'═'*60}")
    print(f"  PHASE 1 — T-Code: ME51N  |  Purchase Requisition")
    print(f"{'═'*60}")
    print(f"  PR Number   : {pr_no}")
    print(f"  Material    : {material} — {mat['description']}")
    print(f"  Quantity    : {qty} {mat['unit']}")
    print(f"  Plant       : {ORG['plant']}  |  Storage Loc: {ORG['storage_loc']}")
    print(f"  Acct Cat.   : {account_category}  |  Status: OPEN")
    return pr_no


def release_pr(pr_no: str) -> None:
    """T-Code ME54N — Release / Approve PR."""
    pr = _store["pr"].get(pr_no)
    if not pr:
        raise ValueError(f"PR {pr_no} not found.")
    pr["release_status"] = "RELEASED"
    print(f"\n  [ME54N] PR {pr_no} RELEASED by Procurement Manager ✓")


# ══════════════════════════════════════════════
#  PHASE 2 — RFQ & Quotation  (ME41 / ME47 / ME49)
# ══════════════════════════════════════════════
def create_rfq(pr_no: str, vendors: list, deadline_days: int = 7) -> str:
    """T-Code ME41 — Create Request for Quotation referencing PR."""
    pr = _store["pr"].get(pr_no)
    if not pr or pr["release_status"] != "RELEASED":
        raise ValueError("PR must be released before RFQ creation.")

    rfq_no = _next("rfq")
    _store["rfq"][rfq_no] = {
        "pr_ref"      : pr_no,
        "material"    : pr["material"],
        "qty"         : pr["qty"],
        "vendors"     : vendors,
        "deadline"    : date.today() + timedelta(days=deadline_days),
        "purch_org"   : ORG["purch_org"],
        "status"      : "SENT",
    }
    _store["quotes"][rfq_no] = []
    print(f"\n{'═'*60}")
    print(f"  PHASE 2 — T-Code: ME41  |  Request for Quotation")
    print(f"{'═'*60}")
    print(f"  RFQ Number  : {rfq_no}  (ref. PR {pr_no})")
    print(f"  Vendors     : {', '.join(vendors)}")
    print(f"  Deadline    : {date.today() + timedelta(days=deadline_days)}")
    return rfq_no


def record_quotations(rfq_no: str) -> dict:
    """T-Code ME47 — Record vendor quotations (simulated prices)."""
    rfq = _store["rfq"].get(rfq_no)
    if not rfq:
        raise ValueError(f"RFQ {rfq_no} not found.")

    mat_val = MATERIAL_MASTER[rfq["material"]]["valuation"]
    quotes = []
    print(f"\n  [ME47] Vendor Quotations for RFQ {rfq_no}")
    print(f"  {'Vendor':<20} {'Unit Price (INR)':>18} {'Lead Days':>10}")
    print(f"  {'─'*50}")
    for v in rfq["vendors"]:
        # simulate competitive pricing ±20 % around material valuation
        price = round(mat_val * random.uniform(0.80, 1.20), 2)
        lead  = random.randint(3, 10)
        quotes.append({"vendor": v, "price": price, "lead_days": lead})
        print(f"  {v:<20} {price:>18.2f} {lead:>10}")

    _store["quotes"][rfq_no] = quotes
    return {q["vendor"]: q for q in quotes}


def price_comparison(rfq_no: str) -> str:
    """T-Code ME49 — Price comparison; returns best vendor."""
    quotes = _store["quotes"].get(rfq_no, [])
    if not quotes:
        raise ValueError("No quotations recorded.")

    best = min(quotes, key=lambda q: q["price"])
    print(f"\n  [ME49] Price Comparison — Best Vendor: "
          f"{best['vendor']} @ INR {best['price']:.2f}/unit")
    return best["vendor"]


# ══════════════════════════════════════════════
#  PHASE 3 — Purchase Order  (ME21N)
# ══════════════════════════════════════════════
def create_purchase_order(pr_no: str, rfq_no: str, vendor: str) -> str:
    """T-Code ME21N — Create Purchase Order referencing PR/RFQ."""
    pr    = _store["pr"][pr_no]
    quote = next((q for q in _store["quotes"][rfq_no]
                  if q["vendor"] == vendor), None)
    if not quote:
        raise ValueError(f"No quote from vendor {vendor} in RFQ {rfq_no}.")

    po_no = _next("po")
    net_value = round(pr["qty"] * quote["price"], 2)
    _store["po"][po_no] = {
        "status"         : "OPEN",
        "pr_ref"         : pr_no,
        "rfq_ref"        : rfq_no,
        "vendor"         : vendor,
        "material"       : pr["material"],
        "qty"            : pr["qty"],
        "unit_price"     : quote["price"],
        "net_value"      : net_value,
        "currency"       : "INR",
        "plant"          : ORG["plant"],
        "purch_org"      : ORG["purch_org"],
        "purch_group"    : ORG["purch_group"],
        "payment_terms"  : VENDOR_MASTER.get(vendor, {}).get("payment_terms", "OD06"),
        "delivery_date"  : date.today() + timedelta(days=quote["lead_days"]),
        "release_status" : "PENDING",
        "gr_qty"         : 0,
        "ir_qty"         : 0,
    }
    print(f"\n{'═'*60}")
    print(f"  PHASE 3 — T-Code: ME21N  |  Purchase Order")
    print(f"{'═'*60}")
    print(f"  PO Number   : {po_no}  (ref. PR {pr_no} / RFQ {rfq_no})")
    print(f"  Vendor      : {vendor}")
    print(f"  Material    : {pr['material']}  |  Qty: {pr['qty']} {pr['unit']}")
    print(f"  Unit Price  : INR {quote['price']:.2f}  |  Net Value: INR {net_value:,.2f}")
    print(f"  Delivery    : {_store['po'][po_no]['delivery_date']}")
    print(f"  Pay Terms   : {_store['po'][po_no]['payment_terms']}")
    return po_no


def release_po(po_no: str) -> None:
    """T-Code ME29N — Multi-level release of PO."""
    po = _store["po"].get(po_no)
    if not po:
        raise ValueError(f"PO {po_no} not found.")
    po["release_status"] = "RELEASED"
    print(f"\n  [ME29N] PO {po_no} RELEASED (multi-level approval) ✓")
    print(f"  [ME9F]  PO output printed/emailed to vendor {po['vendor']} ✓")


# ══════════════════════════════════════════════
#  PHASE 4 — Goods Receipt  (MIGO / MT101)
# ══════════════════════════════════════════════
def post_goods_receipt(po_no: str, received_qty: float) -> str:
    """T-Code MIGO (MT101) — Post Goods Receipt against PO."""
    po  = _store["po"].get(po_no)
    mat = MATERIAL_MASTER.get(po["material"]) if po else None
    if not po or po["release_status"] != "RELEASED":
        raise ValueError("PO must be released before GR posting.")
    if received_qty > po["qty"]:
        raise ValueError("GR quantity exceeds PO quantity.")

    gr_no  = _next("gr")
    fi_doc = _next("fi")
    stock_value = round(received_qty * po["unit_price"], 2)

    # Update stock
    MATERIAL_MASTER[po["material"]]["stock"] += received_qty
    po["gr_qty"] = received_qty

    # FI Accounting Document: Dr Stock / Cr GR/IR Clearing
    fi_entry = {
        "fi_doc"     : fi_doc,
        "ref"        : f"GR {gr_no}",
        "date"       : date.today(),
        "entries"    : [
            {"account": "Stock A/c (BSX)",       "dr": stock_value, "cr": 0},
            {"account": "GR/IR Clearing (WRX)",  "dr": 0,          "cr": stock_value},
        ]
    }
    _store["fi_docs"].append(fi_entry)
    _store["gr"][gr_no] = {
        "po_ref"        : po_no,
        "material"      : po["material"],
        "qty_received"  : received_qty,
        "storage_loc"   : ORG["storage_loc"],
        "posting_date"  : date.today(),
        "material_doc"  : gr_no,
        "fi_doc"        : fi_doc,
    }

    print(f"\n{'═'*60}")
    print(f"  PHASE 4 — T-Code: MIGO (MT101)  |  Goods Receipt")
    print(f"{'═'*60}")
    print(f"  Material Doc : {gr_no}  |  FI Doc: {fi_doc}")
    print(f"  PO Reference : {po_no}  |  Vendor: {po['vendor']}")
    print(f"  Qty Received : {received_qty} {mat['unit'] if mat else ''}")
    print(f"  Storage Loc  : {ORG['storage_loc']}")
    print(f"  Stock (after): {MATERIAL_MASTER[po['material']]['stock']} {mat['unit'] if mat else ''}")
    print(f"\n  FI Document  : {fi_doc}  (Auto-posted)")
    print(f"  {'Account':<30} {'Debit':>12} {'Credit':>12}")
    print(f"  {'─'*56}")
    for e in fi_entry["entries"]:
        print(f"  {e['account']:<30} {e['dr']:>12.2f} {e['cr']:>12.2f}")
    return gr_no


# ══════════════════════════════════════════════
#  PHASE 5 — Invoice Verification  (MIRO)
# ══════════════════════════════════════════════
def post_invoice_verification(po_no: str, gr_no: str,
                               invoice_qty: float, invoice_amount: float,
                               tax_pct: float = 18.0) -> str:
    """T-Code MIRO — 3-way match & Invoice Verification."""
    po = _store["po"].get(po_no)
    gr = _store["gr"].get(gr_no)
    if not po or not gr:
        raise ValueError("Invalid PO or GR reference.")

    # ── 3-Way Match ──────────────────────────
    po_value       = round(po["qty"] * po["unit_price"], 2)
    gr_value       = round(gr["qty_received"] * po["unit_price"], 2)
    expected_base  = round(invoice_qty * po["unit_price"], 2)
    variance_pct   = abs(invoice_amount - expected_base) / expected_base * 100

    inv_no = _next("inv")
    fi_doc = _next("fi")
    tax_amt    = round(invoice_amount * tax_pct / 100, 2)
    total_inv  = round(invoice_amount + tax_amt, 2)
    blocked    = variance_pct > TOLERANCE_PCT

    # FI Accounting Document: Dr GR/IR Clearing / Dr Input Tax / Cr Vendor
    fi_entry = {
        "fi_doc"  : fi_doc,
        "ref"     : f"INV {inv_no}",
        "date"    : date.today(),
        "entries" : [
            {"account": "GR/IR Clearing (WRX)",    "dr": invoice_amount, "cr": 0},
            {"account": "Input Tax (VST)",          "dr": tax_amt,        "cr": 0},
            {"account": f"Vendor A/c ({po['vendor']})", "dr": 0,          "cr": total_inv},
        ]
    }
    _store["fi_docs"].append(fi_entry)
    po["ir_qty"] = invoice_qty

    _store["invoice"][inv_no] = {
        "po_ref"         : po_no,
        "gr_ref"         : gr_no,
        "vendor"         : po["vendor"],
        "invoice_qty"    : invoice_qty,
        "base_amount"    : invoice_amount,
        "tax_pct"        : tax_pct,
        "tax_amount"     : tax_amt,
        "total_amount"   : total_inv,
        "variance_pct"   : variance_pct,
        "blocked"        : blocked,
        "fi_doc"         : fi_doc,
        "status"         : "BLOCKED" if blocked else "POSTED",
        "due_date"       : date.today() + timedelta(days=30),
    }

    print(f"\n{'═'*60}")
    print(f"  PHASE 5 — T-Code: MIRO  |  Invoice Verification")
    print(f"{'═'*60}")
    print(f"  Invoice No   : {inv_no}  |  FI Doc: {fi_doc}")
    print(f"  Vendor       : {po['vendor']}")
    print(f"\n  ── 3-Way Match ──────────────────────────────────────")
    print(f"  PO Value     : INR {po_value:>12,.2f}")
    print(f"  GR Value     : INR {gr_value:>12,.2f}")
    print(f"  Invoice Base : INR {invoice_amount:>12,.2f}")
    print(f"  Variance     : {variance_pct:.2f}%  "
          f"({'WITHIN' if not blocked else 'EXCEEDS'} {TOLERANCE_PCT}% tolerance)")
    print(f"\n  Tax ({tax_pct}%)   : INR {tax_amt:>12,.2f}")
    print(f"  Total Payable: INR {total_inv:>12,.2f}")
    print(f"  Due Date     : {_store['invoice'][inv_no]['due_date']}")
    print(f"  Status       : {'⚠ BLOCKED — Release via MRBR' if blocked else '✓ POSTED'}")
    print(f"\n  FI Document  : {fi_doc}  (Auto-posted)")
    print(f"  {'Account':<35} {'Debit':>10} {'Credit':>10}")
    print(f"  {'─'*57}")
    for e in fi_entry["entries"]:
        print(f"  {e['account']:<35} {e['dr']:>10.2f} {e['cr']:>10.2f}")
    return inv_no


def release_blocked_invoice(inv_no: str) -> None:
    """T-Code MRBR — Release blocked invoice."""
    inv = _store["invoice"].get(inv_no)
    if not inv:
        raise ValueError(f"Invoice {inv_no} not found.")
    if inv["blocked"]:
        inv["blocked"] = False
        inv["status"]  = "POSTED"
        print(f"\n  [MRBR] Invoice {inv_no} released by Finance Manager ✓")


# ══════════════════════════════════════════════
#  PHASE 6 — Vendor Payment  (F110 — APP)
# ══════════════════════════════════════════════
def run_automatic_payment_program(company_code: str, vendor: str) -> list:
    """T-Code F110 — Automatic Payment Program (APP)."""
    print(f"\n{'═'*60}")
    print(f"  PHASE 6 — T-Code: F110  |  Automatic Payment Program")
    print(f"{'═'*60}")
    print(f"  Company Code : {company_code}")
    print(f"  Vendor       : {vendor}")
    print(f"  Run Date     : {date.today()}")

    # ── Proposal Run ─────────────────────────
    due_invoices = [
        inv for inv_no, inv in _store["invoice"].items()
        if inv["vendor"] == vendor
        and not inv["blocked"]
        and inv["status"] == "POSTED"
        and inv["due_date"] <= date.today() + timedelta(days=30)
    ]

    print(f"\n  ── Proposal Run ─────────────────────────────────────")
    print(f"  {'Invoice':>10} {'Due Date':>12} {'Amount (INR)':>16} {'Status':>10}")
    print(f"  {'─'*52}")
    pay_docs = []
    for inv in due_invoices:
        inv_no = [k for k, v in _store["invoice"].items() if v is inv][0]
        print(f"  {inv_no:>10} {str(inv['due_date']):>12} "
              f"{inv['total_amount']:>16,.2f} {'SELECTED':>10}")

    if not due_invoices:
        print(f"  (No invoices due for vendor {vendor})")
        return []

    # ── Payment Run ──────────────────────────
    print(f"\n  ── Payment Run ──────────────────────────────────────")
    for inv in due_invoices:
        pay_no = _next("pay")
        fi_doc = _next("fi")

        fi_entry = {
            "fi_doc"  : fi_doc,
            "ref"     : f"PAY {pay_no}",
            "date"    : date.today(),
            "entries" : [
                {"account": f"Vendor A/c ({vendor})", "dr": inv["total_amount"], "cr": 0},
                {"account": "Bank Outgoing (HDFC)",   "dr": 0, "cr": inv["total_amount"]},
            ]
        }
        _store["fi_docs"].append(fi_entry)
        inv["status"] = "PAID"

        _store["payment"][pay_no] = {
            "inv_ref"  : [k for k, v in _store["invoice"].items() if v is inv][0],
            "vendor"   : vendor,
            "amount"   : inv["total_amount"],
            "method"   : "BANK_TRANSFER",
            "fi_doc"   : fi_doc,
            "date"     : date.today(),
        }
        pay_docs.append(pay_no)

        print(f"  Payment Doc  : {pay_no}  |  FI Doc: {fi_doc}")
        print(f"  Amount Paid  : INR {inv['total_amount']:,.2f}")
        print(f"  Method       : Bank Transfer → {VENDOR_MASTER.get(vendor, {}).get('bank','N/A')}")
        print(f"\n  FI Document  : {fi_doc}  (Auto-posted — Vendor cleared)")
        print(f"  {'Account':<35} {'Debit':>10} {'Credit':>10}")
        print(f"  {'─'*57}")
        for e in fi_entry["entries"]:
            print(f"  {e['account']:<35} {e['dr']:>10.2f} {e['cr']:>10.2f}")

    return pay_docs


# ══════════════════════════════════════════════
#  Summary Report — FK10N / FBL1N equivalent
# ══════════════════════════════════════════════
def print_p2p_summary():
    print(f"\n{'═'*60}")
    print(f"  P2P CYCLE SUMMARY — KIIT Enterprises Pvt. Ltd.")
    print(f"{'═'*60}")

    total_paid = sum(p["amount"] for p in _store["payment"].values())
    print(f"\n  Purchase Requisitions : {len(_store['pr'])}")
    print(f"  RFQs Issued           : {len(_store['rfq'])}")
    print(f"  Purchase Orders       : {len(_store['po'])}")
    print(f"  Goods Receipts        : {len(_store['gr'])}")
    print(f"  Invoices Posted       : {len(_store['invoice'])}")
    print(f"  Payments Made         : {len(_store['payment'])}")
    print(f"  Total Paid (INR)      : {total_paid:,.2f}")
    print(f"  FI Documents          : {len(_store['fi_docs'])}")

    print(f"\n  ── Document Trail ───────────────────────────────────")
    for pr_no, pr in _store["pr"].items():
        print(f"  PR {pr_no} → ", end="")
        po_nos = [k for k,v in _store["po"].items() if v["pr_ref"] == pr_no]
        for po_no in po_nos:
            print(f"PO {po_no} → ", end="")
            gr_nos  = [k for k,v in _store["gr"].items()  if v["po_ref"]  == po_no]
            inv_nos = [k for k,v in _store["invoice"].items() if v["po_ref"] == po_no]
            pay_nos = [k for k,v in _store["payment"].items()
                       if v["inv_ref"] in inv_nos]
            print(f"GR {','.join(gr_nos)} → INV {','.join(inv_nos)} → PAY {','.join(pay_nos)}")
    print(f"\n  ✓ End-to-End P2P Cycle completed with full audit trail.")


# ══════════════════════════════════════════════
#  MAIN — Run full P2P cycle
# ══════════════════════════════════════════════
if __name__ == "__main__":
    random.seed(42)    # reproducible vendor pricing

    print("=" * 60)
    print("  SAP MM — Procure-to-Pay (P2P) Simulation")
    print("  KIIT University | Saheli Patra | 23051293")
    print("=" * 60)

    # ── Phase 1: Purchase Requisition ────────
    pr_no = create_purchase_requisition(
        material="MAT-RAW-001", qty=200, account_category="K"
    )
    release_pr(pr_no)

    # ── Phase 2: RFQ & Quotation ─────────────
    rfq_no = create_rfq(
        pr_no=pr_no,
        vendors=["V-1001", "V-1002", "V-1003"],
        deadline_days=7,
    )
    record_quotations(rfq_no)
    best_vendor = price_comparison(rfq_no)

    # ── Phase 3: Purchase Order ───────────────
    po_no = create_purchase_order(pr_no=pr_no, rfq_no=rfq_no, vendor=best_vendor)
    release_po(po_no)

    # ── Phase 4: Goods Receipt ────────────────
    gr_no = post_goods_receipt(po_no=po_no, received_qty=200)

    # ── Phase 5: Invoice Verification ────────
    po_data    = _store["po"][po_no]
    inv_amount = round(200 * po_data["unit_price"], 2)  # exact match → no variance
    inv_no = post_invoice_verification(
        po_no=po_no,
        gr_no=gr_no,
        invoice_qty=200,
        invoice_amount=inv_amount,
        tax_pct=18.0,
    )

    # ── Phase 6: Vendor Payment ───────────────
    pay_docs = run_automatic_payment_program(
        company_code=ORG["company_code"],
        vendor=best_vendor,
    )

    # ── Summary ───────────────────────────────
    print_p2p_summary()
